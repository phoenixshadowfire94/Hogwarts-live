# Owl Buddy — Hogwarts Live companion asset pack

## Included
- `Owl_Buddy.glb` — assembled stylized 3D owl character.
- `animation_manifest.json` — named component map and animation clip specifications.
- `Owl_Buddy_preview.png` — visual reference preview (if supplied separately).

## Character design
The owl wears a floppy brown wizard hat and a permanent red-and-gold scarf with a crest patch. It has oversized bright blue eyes, a small beak, layered brown/cream feathers, separate left/right wing components, feet, toes and claws.

## Important animation status
The GLB contains a named, multi-part assembled model intended for runtime animation. The JSON file describes idle breathing, blink, looking around, head tilt, wing flap, fly-in, landing and celebration. These clips are **not embedded as baked glTF skeletal animation tracks**. The launcher must animate the named nodes at runtime. For robust wing and head rotation, create pivot parent nodes in the SceneView/Filament scene and attach the corresponding meshes to those pivots. The supplied clip timings and keyframes are starting values.

## Integration notes
1. Copy `Owl_Buddy.glb` and `animation_manifest.json` into the app's model assets directory.
2. Load `Owl_Buddy.glb` through the existing SceneView/Filament loader.
3. Use the node names in `animation_manifest.json` to build animation pivots and tracks.
4. Keep the hat and scarf attached during every animation.
5. Set the companion's scale and dock position in the launcher after checking it on the target TV.

## Validation
The GLB container and scene graph were checked after export. Visual appearance, materials on the target TV, and runtime animation still need to be tested in the app.
