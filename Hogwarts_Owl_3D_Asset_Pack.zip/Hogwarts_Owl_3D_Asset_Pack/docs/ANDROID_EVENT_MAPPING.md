# Android event mapping

| Launcher event | GLB clip |
|---|---|
| Companion idle | `Idle_Breathe_Bob` (loop) |
| Random blink | `Blink_L` / `Blink_R` |
| Dock focus change | `Look_Around` |
| Owl arrives | `Wing_Flap_Fly` then `Landing_Perch` |
| App selection tap | `Tap_App` |
| Successful launch | `Happy_Celebration` |

Use a glTF 2.0 runtime capable of playing named animation clips. Cross-fade clips where supported; avoid running two clips that animate the same node/property at the same time.
