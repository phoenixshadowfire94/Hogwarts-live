# Hogwarts Owl Companion — 3D Asset Pack

A stylized, low-poly 3D owl companion built from scratch using the supplied owl friend reference sheets. The model uses bright sapphire-blue eyes, a brown crooked wizard hat, a red-and-gold scarf with a small house crest, layered feather wings, and articulated feet.

## Files
- `model/Hogwarts_Owl_BlueEyes.glb` — self-contained glTF 2.0 model with embedded materials and animation clips.
- `model/animation_manifest.json` — clip names and channel counts.
- `source-art/owl_friend1_reference.png` and `source-art/owl_friend2_reference.png` — original supplied reference sheets for provenance and future art direction.

## Animation clips
- `Idle_Breathe_Bob` — gentle body bob, head tilt, wing sway (loop this).
- `Blink_L`, `Blink_R` — independent eye blinks.
- `Look_Around` — head and eye movement.
- `Wing_Flap_Fly` — wing flaps and body lift.
- `Tap_App` — leans forward and reaches with the right wing.
- `Happy_Celebration` — wing flutter and happy bounce.
- `Landing_Perch` — wings fold and body settles.

## Android integration
This is an asset pack, not a compiled APK or a drop-in Android View. The GLB can be rendered by a glTF-capable runtime (for example Filament / SceneView). Load the model once, loop `Idle_Breathe_Bob`, then trigger the other named clips in response to dock focus, app selection, launch, and landing events. Check animation names in `animation_manifest.json`.

Suggested event mapping:
- Dock idle: `Idle_Breathe_Bob` plus occasional `Blink_L` / `Blink_R`.
- Focus changes: `Look_Around`.
- App tap: `Tap_App`.
- App launch success: `Happy_Celebration`.
- Companion arriving on dock: `Wing_Flap_Fly` followed by `Landing_Perch`.

## Notes
The supplied reference sheets are 2D illustrations, not pre-existing 3D geometry. This pack uses them as visual references and builds a new 3D interpretation; it does not directly convert the 2D pixels into a rigged mesh. The model is a starter stylized 3D asset. Before shipping, test scale, camera framing, and performance in the target Android TV renderer.
